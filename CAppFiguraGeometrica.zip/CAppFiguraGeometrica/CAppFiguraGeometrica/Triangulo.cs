﻿namespace CAppFiguraGeometrica
{
    class Triangulo
    {
    }
}
