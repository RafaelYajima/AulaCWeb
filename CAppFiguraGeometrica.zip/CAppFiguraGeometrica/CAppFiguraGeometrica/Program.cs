﻿using CAppFiguraGeometrica_Entity;
using System;

namespace CAppFiguraGeometrica
{
    internal class Program
    {
        static void Main(string[] args)
        {
            FiguraGeometrica figuraGm_01 = new FiguraGeometrica();
            figuraGm_01.SetBase(10.0);
            figuraGm_01.SetAltura(35.5);
            figuraGm_01.CalculaAreaTriangulo();

            FiguraGeometrica figuraGm_02 = new FiguraGeometrica();
            figuraGm_02.SetBase(56.0);
            figuraGm_02.SetAltura(10.5);
            figuraGm_02.CalculaAreaRetangulo();

            Console.WriteLine("Área Triangulo = " + figuraGm_01.GetAreaTriangulo());
            Console.WriteLine("Área Retângulo = " + figuraGm_02.GetAreaRetangulo());
        }
    }
}
